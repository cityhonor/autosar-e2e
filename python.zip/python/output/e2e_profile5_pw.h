#ifndef __E2E_PROFILE5_PW_H__
#define __E2E_PROFILE5_PW_H__

#include "E2E_P05.h"

Std_ReturnType E2E_P05CheckE2EProfile5_0_0x155(const uint8_t *Data, uint8_t Length);

Std_ReturnType E2E_P05CheckE2EProfile5_1_0x156(const uint8_t *Data, uint8_t Length);

#endif //__E2E_PROFILE5_PW_H
