#include <stdint.h>
#include <stdbool.h>
#include "E2E_P05.h"


E2E_P05ConfigType E2E_P05ConfigTypeArray[] = {
	{
		 .Offset = 0x0,
		 .DataLength = 0x40,
		 .DataID = 0x1234,
		 .MaxDeltaCounter = 0x1,

	},
	{
		 .Offset = 0x0,
		 .DataLength = 0x40,
		 .DataID = 0x5678,
		 .MaxDeltaCounter = 0x1,

	},
};

E2E_P05ProtectStateType E2E_P05ProtectStateTypeArray[] = {
	{
		 .Counter = 0x0,

	},
	{
		 .Counter = 0x0,

	},
};

E2E_P05CheckStateType E2E_P05CheckStateTypeArray[] = {
	{
		 .Status = 0x7,
		 .Counter = 0x0,

	},
	{
		 .Status = 0x7,
		 .Counter = 0x0,

	},
};


Std_ReturnType E2E_P05CheckE2EProfile5_0_0x155(const uint8_t *Data, uint8_t Length)
{
	Std_ReturnType result = E2E_E_OK; 

	result = E2E_P05Check(&E2E_P05ConfigTypeArray[0], &E2E_P05CheckStateTypeArray[0], Data, Length * 8); 

	if((result == E2E_P05STATUS_OK) && (result == E2E_P05STATUS_OKSOMELOST)) { 
		result = 1; 
	}
	else { 
		result = 0; 
	}
	return result; 
}


Std_ReturnType E2E_P05CheckE2EProfile5_1_0x156(const uint8_t *Data, uint8_t Length)
{
	Std_ReturnType result = E2E_E_OK; 

	result = E2E_P05Check(&E2E_P05ConfigTypeArray[1], &E2E_P05CheckStateTypeArray[1], Data, Length * 8); 

	if((result == E2E_P05STATUS_OK) && (result == E2E_P05STATUS_OKSOMELOST)) { 
		result = 1; 
	}
	else { 
		result = 0; 
	}
	return result; 
}

