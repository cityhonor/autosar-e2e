import json
import os
import cantools


class E2EProfile5:
    def __init__(self, can_id, data_id, offset, max_delta_counter, data_length, counter, dbc_config_path):
        self.can_id = can_id
        self.data_id = data_id
        self.offset = offset
        self.max_delta_counter = max_delta_counter
        self.data_length = data_length  
        self.counter = counter
        self.dbc_config_path = dbc_config_path
        """ 随便赋值即可 """
        self.status = 7 

class JsonParse:
    def __init__(self, current_path, json_name):
        config_json_path = current_path + json_name
        try:
            with open(config_json_path, 'r') as file:
                self.json_obj = json.load(file)
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON: {e}")
            return None
        
        self.dbc_connfig_list = self.json_obj['dbc_connfig_list']
        self.can_config_list = self.json_obj['can_config_list']
        self.e2e_profile5_list = list()
        self.dicts = dict() 
        # self.dbc_file = load_dbc_file(self.dbc_file_ref['name'])
        # self.dbc_files = list()
        # self.can_configs = list()

        for can_config in self.can_config_list:
            channel = can_config['can_channel_name']
            for item in self.dbc_connfig_list:
                if item['name'] == channel:
                    file_path = current_path + item['file']
                    if os.path.exists(file_path):
                        dbc_file = self.open_dbc_file(file_path)
                        e2e_profile5_config = can_config['e2e_profile5_config']
                        for item in e2e_profile5_config:
                            can_id = int(item['can_id'], 16)
                            message = dbc_file.get_message_by_frame_id(can_id)
                            if message:
                                e2e_profile5_type = item
                                e2e_profile5_type['data_len'] = message.length
                                data_id = int(item['data_id'], 16)
                                self.e2e_profile5_list.append(E2EProfile5(can_id, data_id, item['offset'], item['max_delta_counter'], 
                                                                          message.length * 8, 0, file_path))
                            else:
                                print(f"Error: CAN ID {can_id} not found in DBC file {file_path}")
                        self.dicts.update({f'${file_path}': can_config})
                    else:
                        raise FileNotFoundError(f"Error: DBC file {file_path} does not exist.")
                    
                    break
        
        
        self.output_path = current_path + self.json_obj['output']

        
    def open_dbc_file(self, file_path):
        try:
            dbc_file = cantools.database.load_file(file_path)
            return dbc_file
        except Exception as e:
            raise Exception(f"Error loading DBC file: {e}")
            return None
        
    def dbc_config_parse_by_can_id(self, dbc_file, can_id):
        for message in dbc_file.messages:
            if message.frame_id == can_id:
                return message