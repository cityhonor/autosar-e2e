import json
import src.class_set
import os

def code_gen_const_e2e_p05_config_t(json_obj, current_path, code_gen_config_path, output_path):
    """生成E2E_P05ConfigType的常量定义"""
    try:
        with open(code_gen_config_path, 'r') as f:
            code_gen_cfg = json.load(f)
    except FileNotFoundError:
        print(f"Error: File {code_gen_config_path} not found")
        return
    except json.JSONDecodeError:
        print(f"Error: Failed to decode JSON from {code_gen_config_path}")
        return

    struct_gen_struct = code_gen_cfg['structs']
    const_config_code = []
    const_code_if_c = []
    const_code_if_h = []

    for i in range(len(code_gen_cfg['includes'])):
        const_config_code.append(f"#include {code_gen_cfg['includes'][i]}")
    const_config_code.append("\n")

    
    for i in range(len(struct_gen_struct)):
        struct_gen_array = struct_gen_struct[i]
        const_config_code.append(f"{struct_gen_array['name']} {struct_gen_array['name']}Array[] = {{")
        for j in range(len(json_obj.e2e_profile5_list)):
            const_config_code.append("\t{")
            e2e_config = json_obj.e2e_profile5_list[j]
            """ 配置生成 """
            for k in range(len(struct_gen_array['members'])):
                
                python_member = struct_gen_array['members'][k]['python_member']
                c_member = struct_gen_array['members'][k]['c_member']
                e2e_config_value = hex(e2e_config.__getattribute__(python_member))
                const_config_code.append(f"\t\t .{c_member} = {e2e_config_value},")

            const_config_code.append("\n\t},")
        const_config_code.append("};\n")

    const_code_if_c.append("\n")
    for i in range(len(json_obj.e2e_profile5_list)):
        e2e_config = json_obj.e2e_profile5_list[i]
        try:
            dbc_file = json_obj.open_dbc_file(os.path.join(current_path, e2e_config.dbc_config_path))
        except FileNotFoundError:
            print(f"Error: File {e2e_config.dbc_config_path} not found")
            return
        message = dbc_file.get_message_by_frame_id(e2e_config.can_id)
        if message:
            str = f"Std_ReturnType E2E_P05Check{message.name}_{hex(message.frame_id)}(const uint8_t *Data, uint8_t Length)"
            const_code_if_c.append(str)
            const_code_if_h.append(str + ';\n')
            const_code_if_c.append(f"{{\n\tStd_ReturnType result = E2E_E_OK; \n")
            const_code_if_c.append(f"\tresult = E2E_P05Check(&{struct_gen_struct[0]['name']}Array[{i}], &{struct_gen_struct[2]['name']}Array[{i}], Data, Length * 8); \n")
            const_code_if_c.append(f"\tif((result == E2E_P05STATUS_OK) && (result == E2E_P05STATUS_OKSOMELOST)) {{ \n\t\tresult = 1; \n\t}}")
            const_code_if_c.append(f"\telse {{ \n\t\tresult = 0; \n\t}}")
            const_code_if_c.append(f"\treturn result; \n}}\n\n")

    if not output_path.endswith('.c'):
        output_path += '.c'
    if not os.path.exists(os.path.dirname(output_path)):
        os.makedirs(os.path.dirname(output_path))

    output_path_h = output_path.replace('.c', '.h')
    try:    
        with open(output_path, 'w') as f:
            f.write('\n'.join(const_config_code))
            f.write('\n'.join(const_code_if_c))
    except FileNotFoundError:
        print(f"Error: File {output_path} not found")
        return
    except PermissionError:
        print(f"Error: Permission denied to write to {output_path}")
        return
    
    try:    
        with open(output_path_h, 'w') as f:
            str = f"#ifndef "
            str += (f"__{os.path.basename(output_path_h).replace('.h', '')}_H__\n").upper()
            str += f"#define "
            str += (f"__{os.path.basename(output_path_h).replace('.h', '')}_H__\n").upper()
            str += "\n"
            str += "#include \"E2E_P05.h\"\n\n"
            f.write(str)

            f.write('\n'.join(const_code_if_h))
            str = f"\n#endif "
            str += (f"//__{os.path.basename(output_path_h).replace('.h', '')}_H\n").upper()
            f.write(str)
            
    except FileNotFoundError:
        print(f"Error: File {output_path_h} not found")
        return
    except PermissionError:
        print(f"Error: Permission denied to write to {output_path_h}")
        return
    

    
    return