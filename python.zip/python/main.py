import os
import src.class_set as class_set
import src.generate_c_code as generate_c_code



def start():
    print("start")
    current_path = os.path.dirname(os.path.abspath(__file__))
    current_path = current_path + '/'
    config_json_name = 'config/config.json'
    code_gen_config_path = 'config/code_gen.json'
    code_gen_config_path = current_path + code_gen_config_path
    config = class_set.JsonParse(current_path, config_json_name)
    code_gen = generate_c_code.code_gen_const_e2e_p05_config_t(config, current_path, code_gen_config_path, config.output_path)
    pass



















if __name__ == "__main__":
    start()